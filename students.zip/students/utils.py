def add_cors_headers(headers, path, url):
    headers["Access-Control-Allow-Origin"] = "*"
